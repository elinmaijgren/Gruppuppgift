import React from "react";
import "./Login.css";

const Login = () => {
  return (
    <div className="login-container">
      <h1>Coming soon</h1>
    </div>
  );
};

export default Login;
