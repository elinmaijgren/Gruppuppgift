import React from 'react'

const Checkout = () => {
  const [Checkout, setCheckout] = useState([]);
  
  return (
    <div>
      Checkout
    </div>
  )
}

export default Checkout