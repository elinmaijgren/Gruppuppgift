import React from 'react'


const kundvagnSida = () => {

  return (
    <>

      <div>
        <h1>
          Kundvagn
        </h1>

      </div>
    </>
  )
}

export default kundvagnSida